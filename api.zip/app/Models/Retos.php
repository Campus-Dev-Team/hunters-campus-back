<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Retos extends Model {
    protected $table = "retos";
}

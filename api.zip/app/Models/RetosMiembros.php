<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RetosMiembros extends Model
{
    public $timestamps = false;
}
